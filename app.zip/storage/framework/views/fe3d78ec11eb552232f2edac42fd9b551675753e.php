<!-- Navigation -->
<h6 class="navbar-heading text-muted">
    <?php if(auth()->user()->role == 'admin'): ?>
    Gestionar Datos
    <?php else: ?>
    Menu
    <?php endif; ?>
</h6>
<ul class="navbar-nav">
    <?php if(auth()->user()->role == 'admin'): ?>
    <li class="nav-item">
        <a class="nav-link" href="../public/home">
            <i class="ni ni-tv-2 text-red"></i> Dashboard
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="../public/specialties">
            <i class="ni ni-planet text-blue"></i> Especialidades
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="../public/doctors">
            <i class="ni ni-ambulance text-orange"></i> Medicos
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="../public/patients">
            <i class="ni ni-single-02 text-silver"></i> Pacientes
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="../public/appointments">
            <i class="ni ni-time-alarm text-yellow"></i> Citas Medicas
        </a>
    </li>
    <?php elseif(auth()->user()->role == 'doctor'): ?>
    <li class="nav-item">
        <a class="nav-link" href="../public/schedule">
            <i class="ni ni-calendar-grid-58 text-danger"></i> Gestionar Horario
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="../public/appointments">
            <i class="ni ni-time-alarm text-yellow"></i> Mis citas
        </a>
    </li>

    <?php else: ?>
    <li class="nav-item">
        <a class="nav-link" href="../public/appointments/create">
            <i class="ni ni-send text-danger"></i> Reservar Cita
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="../public/appointments">
            <i class="ni ni-time-alarm text-yellow"></i> Mis citas
        </a>
    </li>
    <?php endif; ?>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                document.getElementById('formLogout').submit();">
            <i class="ni ni-key-25 text-info"></i> Cerrar Sesión
        </a>
        <form action="<?php echo e(route('logout')); ?>" method="POST" style="display:none;" id="formLogout">
            <?php echo csrf_field(); ?>
        </form>
    </li>
</ul>
<?php if(auth()->user()->role == 'admin'): ?>
<!-- Divider -->
<hr class="my-3">
<!-- Heading -->
<h6 class="navbar-heading text-muted">Reportes</h6>
<!-- Navigation -->
<ul class="navbar-nav mb-md-3">
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/charts/appointments/line')); ?>">
            <i class="ni ni-collection text-orange"></i> Frecuencia de citas
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/charts/doctors/column')); ?>">
            <i class="ni ni-spaceship text-red"></i> Medicos mas activos
        </a>
    </li>
</ul>
<?php endif; ?>