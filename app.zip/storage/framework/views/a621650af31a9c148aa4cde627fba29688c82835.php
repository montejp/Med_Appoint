

<?php $__env->startSection('content'); ?>

<div class="card shadow">
    <div class="card-header border-0">
        <div class="row align-items-center">
            <div class="col">
                <h3 class="mb-0">Cancelar cita</h3>
            </div>

        </div>
    </div>

    <div class="card-body">
        <?php if(session('notification')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('notification')); ?>

        </div>
        <?php endif; ?>

        <?php if($role == 'patient'): ?>
        <p>
            Estás a punto de cancelar tu cita reservada con el <strong>MEDICO:</strong>
            <?php echo e($appointment->doctor->name); ?>

            (especialidad <?php echo e($appointment->specialty->name); ?>)
            para el día <?php echo e($appointment->scheduled_date); ?>:
        </p>
        <?php elseif($role == 'doctor'): ?>
        <p>
            Estás a punto de cancelar tu cita con el <strong>PACIENTE:</strong>
            <?php echo e($appointment->patient->name); ?>

            (especialidad <?php echo e($appointment->specialty->name); ?>)
            para el día <?php echo e($appointment->scheduled_date); ?>

            (hora <?php echo e($appointment->scheduled_time_12); ?>):
        </p>
        <?php else: ?>
        <p>
            Estás a punto de cancelar la cita reservada
            por el <strong>PACIENTE:</strong> <?php echo e($appointment->patient->name); ?>

            para ser atendido por el <strong>MEDICO:</strong> <?php echo e($appointment->doctor->name); ?>

            (especialidad <?php echo e($appointment->specialty->name); ?>)
            el día <?php echo e($appointment->scheduled_date); ?>

            (hora <?php echo e($appointment->scheduled_time_12); ?>):
        </p>
        <?php endif; ?>

        <form action="<?php echo e(url('/appointments/'.$appointment->id.'/cancel')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="justification">Por favor cuéntanos el motivo de la cancelación:</label>
                <textarea required id="justification" name="justification" rows="3" class="form-control"></textarea>
            </div>

            <button class="btn btn-danger" type="submit">Cancelar cita</button>
            <a href="<?php echo e(url('/appointments')); ?>" class="btn btn-default">
                Volver al listado de citas sin cancelar
            </a>
        </form>


    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>