<div class="table-responsive">
    <!-- Tabla especialidades -->
    <table class="table align-items-center table-flush">
        <thead class="thead-light">
            <tr>
                <th scope="col">Descripción</th>
                <th scope="col">Especialidad</th>
                <?php if($role == 'patient'): ?>
                <th scope="col">Médico</th>
                <?php elseif($role == 'doctor'): ?>
                <th scope="col">Paciente</th>
                <?php endif; ?>
                <th scope="col">Fecha</th>
                <th scope="col">Hora</th>
                <th scope="col">Tipo</th>
                <th scope="col">Opciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pendingAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row">
                    <?php echo e($appointment->description); ?>

                </th>
                <td>
                    <?php echo e($appointment->specialty->name); ?>

                </td>
                <?php if($role == 'patient'): ?>
                <td><?php echo e($appointment->doctor->name); ?></td>
                <?php elseif($role == 'doctor'): ?>
                <td><?php echo e($appointment->patient->name); ?></td>
                <?php endif; ?>
                <td>
                    <?php echo e($appointment->scheduled_date); ?>

                </td>
                <td>
                    <?php echo e($appointment->scheduled_time_12); ?>

                </td>
                <td>
                    <?php echo e($appointment->type); ?>

                </td>

                <td>
                    <?php if($role == 'admin'): ?>
                    <a class="btn btn-sm btn-primary" title="Ver cita"
                        href="<?php echo e(url('/appointments/'.$appointment->id)); ?>">
                        Ver
                    </a>
                    <?php endif; ?>

                    <?php if($role == 'doctor' || $role == 'admin'): ?>
                    <form action="<?php echo e(url('/appointments/'.$appointment->id.'/confirm')); ?>" method="POST"
                        class="d-inline-block">
                        <?php echo csrf_field(); ?>

                        <button class="btn btn-sm btn-success" type="submit" data-toggle="tooltip"
                            title="Confirmar cita">
                            <i class="ni ni-check-bold"></i>
                        </button>
                    </form>
                    <a href="<?php echo e(url('/appointments/'.$appointment->id.'/cancel')); ?>" class="btn btn-sm btn-danger">
                        <i class="ni ni-fat-delete"></i>
                    </a>
                    <?php else: ?>
                    <form action="<?php echo e(url('/appointments/'.$appointment->id.'/cancel')); ?>" method="POST"
                        class="d-inline-block">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-sm btn-danger" type="submit" data-toggle="tooltip" title="Cancelar Cita">
                            <i class="ni ni-fat-delete"></i>
                        </button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<!-- PAGINACION-->
<div class="card-body">
    <?php echo e($pendingAppointments->links()); ?>

</div>