<?php $__env->startSection('content'); ?>
        
<div class="card shadow">
  <div class="card-header border-0">
    <div class="row align-items-center">
      <div class="col">
        <h3 class="mb-0">Cita #<?php echo e($appointment->id); ?></h3>
      </div> 
    </div>
  </div>
      
  <div class="card-body">

    <ul>
        <li>
          <strong>Fecha:</strong> <?php echo e($appointment->scheduled_date); ?>

        </li>
        <li>
          <strong>Hora:</strong> <?php echo e($appointment->scheduled_time_12); ?>

        </li>
        
        <?php if($role == 'patient' || $role == 'admin'): ?>
          <li>
            <strong>Médico:</strong> <?php echo e($appointment->doctor->name); ?>

          </li>
        <?php endif; ?>

        <?php if($role == 'doctor' || $role == 'admin'): ?>
          <li>
            <strong>Paciente:</strong> <?php echo e($appointment->patient->name); ?>

          </li>
        <?php endif; ?>

        <li>
          <strong>Especialidad:</strong> <?php echo e($appointment->specialty->name); ?>

        </li>

        <li>
          <strong>Tipo:</strong> <?php echo e($appointment->type); ?>

        </li>
        <li>
          <strong>Estado:</strong> 
          <?php if($appointment->status == 'Cancelada'): ?>
            <span class="badge badge-danger">Cancelada</span>
          <?php else: ?>
            <span class="badge badge-success"><?php echo e($appointment->status); ?></span>
          <?php endif; ?>
        </li>
      </ul>

      <?php if($appointment->status == 'Cancelada'): ?>
        <div class="alert alert-warning">
          <p>Acerca de la cancelación:</p>
          <ul>
            <?php if($appointment->cancellation): ?>
              <li>
                <strong>Fecha de cancelación:</strong>
                <?php echo e($appointment->cancellation->created_at); ?>

              </li>
              <li>
                <strong>¿Quién canceló la cita?:</strong>
                <?php if(auth()->id() == $appointment->cancellation->cancelled_by_id): ?>
                  Tú
                <?php else: ?>
                  <?php echo e($appointment->cancellation->cancelled_by->name); ?>

                <?php endif; ?>
              </li>
              <li>
                <strong>Justificación:</strong>
                <?php echo e($appointment->cancellation->justification); ?>

              </li>
            <?php else: ?>
              <li>Esta cita fue cancelada antes de su confirmación.</li>
            <?php endif; ?>
          </ul>
        </div>
      <?php endif; ?>

      <a href="<?php echo e(url('/appointments')); ?>" class="btn btn-default">
        Volver
      </a>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>